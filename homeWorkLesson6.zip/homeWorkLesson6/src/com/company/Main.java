package com.company;

public class Main {

    public static void main(String[] args) {
        Boss boss = new Boss();
        boss.setDamage(50);
        boss.setHealth(900);
//        boss.setWeapon(boss.weapon);
//        boss.setWeapon(boss.weapon);
        System.out.println("Boss health: " + boss.getHealth() + "\nBoss damage: " + boss.getDamage() + "\nBoss name gun: "
                + boss.getWeapon() + "\nBoss type gun: " + boss.getWeapon());

        System.out.println("___________________");

        boss.setDamage(100);
        boss.setHealth(500);
//        boss.setWeapon();
//        boss.setWeapon();
        System.out.println(boss.printInfo());
    }
}
