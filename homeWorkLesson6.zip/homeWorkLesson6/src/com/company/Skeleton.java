package com.company;

public class Skeleton extends Boss{
    int numberOfArrows;

    public int getNumberOfArrows() {
        return numberOfArrows;
    }
    public String printInfo(){
        return super.printInfo() + getNumberOfArrows();
    }
}
