package com.company;

public class Skeleton extends Boss{

    public Skeleton(String numberOfArrows) {
        super(numberOfArrows);
    }

    @Override
    public String printInfo(){
        return  super.getNumberOfArrows()+" Стрелы";
    }
}
