package com.company;

public class Boss extends GameEntity {
    private String numberOfArrows;


    public String getNumberOfArrows() {
        return numberOfArrows;
    }

    Weapon weapon = new Weapon();

    public Boss(String numberOfArrows, int health, int damage){
        super(health, damage);
        this.numberOfArrows = numberOfArrows;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
    public String printInfo(){

        return  numberOfArrows + "\n Это стрелы" + "\nBoss health: " +super.getHealth() + "\nBoss damage: " + super.getDamage() + "\nBoss name gun: "+super.getNameGun() +"\nBoss type gun: " + super.getTypeGun();
    }

}
