package com.company;

public class Weapon {
   private String typeGun;
    private String nameGun;

    public String getTypeGun() {
        return typeGun;
    }

    public void setTypeGun(String typeGun) {
        this.typeGun = typeGun;
    }

    public String getNameGun() {
        return nameGun;
    }

    public void setNameGun(String nameGun) {
        this.nameGun = nameGun;
    }
}
